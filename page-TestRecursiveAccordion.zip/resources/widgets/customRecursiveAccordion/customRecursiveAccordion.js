(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customRecursiveAccordion', function() {
    return {
      controllerAs: 'ctrl',
      controller: /**
 * The controller is a JavaScript function that augments the AngularJS scope and exposes functions that can be used in the custom widget template
 * 
 * Custom widget properties defined on the right can be used as variables in a controller with $scope.properties
 * To use AngularJS standard services, you must declare them in the main function arguments.
 * 
 * You can leave the controller empty if you do not need it.
 */
function ($scope) {

/*$scope.data = [
    new Node('Group 1', [
        new Node('Sub 1.1', [
            new Node('Sub 1.1.1', [
                new Node('Child 1.1.1.1'),
                new Node('Child 1.1.1.2')]),
            new Node('Sub 1.1.2', [
                new Node('Child 1.1.2.1'),
                new Node('Child 1.1.2.2'),
                new Node('Child 1.1.2.3')])]),
        new Node('Sub 1.2', [
            new Node('Child 1.2.1'),
            new Node('Child 1.2.2')])]),
    new Node('Group 2', [
        new Node('Sub 2.1', [
            new Node('Child 2.1.1')])])];
*/            
//console.log("data is "+ JSON.stringify($scope.data));
            
$scope.data = $scope.properties.accordionTree;
/*[
  {
    "name": "Group 1",
    "children": [
      {
        "name": "Sub 1.1",
        "children": [
          {
            "name": "Sub 1.1.1",
            "children": [
              {
                "name": "Child 1.1.1.1",
                "children": [],
                "text": "1.1.1.1"
              },
              {
                "name": "Child 1.1.1.2",
                "children": [],
                "text": "1.1.1.2"
              }
            ],
            "text": "1.1"
          },
          {
            "name": "Sub 1.1.2",
            "children": [
              {
                "name": "Child 1.1.2.1",
                "children": [],
                "text": "1.1.2.1"
              },
              {
                "name": "Child 1.1.2.2",
                "children": [],
                "text": "1.1.2.2"
              },
              {
                "name": "Child 1.1.2.3",
                "children": [],
                "text": "1.1.2.3"
              }
            ]
          }
        ],
        "text": "1.1"
      },
      {
        "name": "Sub 1.2",
        "children": [
          {
            "name": "Child 1.2.1",
            "children": [],
            "text": "1.2.1"
          },
          {
            "name": "Child 1.2.2",
            "children": [],
            "text": "1.2.2"
          }
        ],
        "text": "1.2"
      }
    ],
    "text": "1"
  },
  {
    "name": "Group 2",
    "children": [
      {
        "name": "Sub 2.1",
        "children": [
          {
            "name": "Child 2.1.1",
            "children": [],
            "text": "2.1.1"
          }
        ],
        "text": "2.1"
      }
    ],
    "text": "2"
  }
];
*/
},
      template: '<!-- The custom widget template is defined here\n   - You can use standard HTML tags and AngularJS built-in directives, scope and interpolation system\n   - Custom widget properties defined on the right can be used as variables in a templates with properties.newProperty\n   - Functions exposed in the controller can be used with ctrl.newFunction()\n   - You can use the \'environment\' property injected in the scope when inside the Editor whiteboard. It allows to define a mockup\n     of the Custom Widget to be displayed in the whiteboard only. By default the widget is represented by an auto-generated icon\n     and its name (See the <span> below).\n-->\n \n<span ng-if="environment"><identicon name="{{environment.component.id}}" size="30" background-color="[255,255,255, 0]" foreground-color="[51,51,51]"></identicon> {{environment.component.name}}</span>\n\n    <div>\n      <h1>Test</h1>\n      <node-list ng-model="data"></node-list>\n    </div>\n'
    };
  });
