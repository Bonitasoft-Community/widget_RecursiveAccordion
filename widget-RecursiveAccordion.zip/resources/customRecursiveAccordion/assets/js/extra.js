function Node(name, children) {
    this.name = name;
    this.children = children || [];
}

angular.module('bonitasoft.ui.widgets')

.directive('nodeList', function($compile) {
    return {
        restrict: 'E',
        terminal: true,
        scope: {
            nodes: '=ngModel'
        },
        link: function ($scope, $element, $attrs) {
            if (angular.isArray($scope.nodes)) {
                $element.append('<accordion close-others="false"><node ng-repeat="item in nodes" ng-model="item"></node></accordion>');
            } 
            $compile($element.contents())($scope.$new());
        }
    };
})

.directive('node', function($compile) {
    return {
        restrict: 'E',
        terminal: true,
        scope: {
            node: '=ngModel'
        },
        link: function ($scope, $element, $attrs) {
            if (angular.isArray($scope.node.children) && $scope.node.children.length > 0) {
                $element.append('<accordion-group><accordion-heading>{{node.name}}</accordion-heading><node-list ng-model="node.children"></node-list><div>{{node.text}}</div></accordion-group>');
            } else {
                $element.append('<accordion-group><accordion-heading>{{node.name}}</accordion-heading><div>{{node.text}}</div></accordion-group>');
            }
            $compile($element.contents())($scope.$new());
        }
    };
})